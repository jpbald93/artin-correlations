 




import Mathlib.NumberTheory.LegendreSymbol.QuadraticReciprocity
import Mathlib.Tactic
import Artin.PrimitiveRootBridge

set_option linter.style.header false

 














































namespace ArtinExclusion

open ZMod

variable {p : ℕ} [Fact p.Prime]

 

private theorem legendreSym_sq' {s : ℤ} (hs : ((s : ZMod p)) ≠ 0) :
    legendreSym p (s ^ 2) = 1 := by
  have : legendreSym p (s ^ 2) = (legendreSym p s) ^ 2 := by
    rw [sq, sq, legendreSym.mul]
  rw [this]
  rcases legendreSym.eq_one_or_neg_one p hs with h | h <;> rw [h] <;> norm_num

 











theorem not_both_nonresidue_of_barring_character
    {a b d u v : ℤ}
    (hrel : d * u ^ 2 = a * b * v ^ 2)
    (hu : ((u : ZMod p)) ≠ 0) (hv : ((v : ZMod p)) ≠ 0)
    (hd : legendreSym p d = -1) :
    ¬ (legendreSym p a = -1 ∧ legendreSym p b = -1) := by
  rintro ⟨hA, hB⟩
  
  have h := congrArg (fun z : ℤ => legendreSym p z) hrel
  simp only [legendreSym.mul, legendreSym_sq' hu, legendreSym_sq' hv, mul_one] at h
  
  rw [hA, hB, hd] at h
  norm_num at h

 




theorem not_both_primitiveRoot_of_barring_character
    (hp2 : p ≠ 2)
    {a b d u v : ℤ}
    (hrel : d * u ^ 2 = a * b * v ^ 2)
    (hu : ((u : ZMod p)) ≠ 0) (hv : ((v : ZMod p)) ≠ 0)
    (hd : legendreSym p d = -1)
    (ha : IsPrimitiveRoot ((a : ZMod p)) (p - 1))
    (hb : IsPrimitiveRoot ((b : ZMod p)) (p - 1)) :
    False :=
  not_both_nonresidue_of_barring_character hrel hu hv hd
    ⟨legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 ha,
     legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 hb⟩

 








theorem not_all_three_nonresidue_of_pair
    {a b c s t : ℤ}
    (hrel : c * s ^ 2 = a * b * t ^ 2)
    (hs : ((s : ZMod p)) ≠ 0) (ht : ((t : ZMod p)) ≠ 0) :
    ¬ (legendreSym p a = -1 ∧ legendreSym p b = -1 ∧ legendreSym p c = -1) := by
  rintro ⟨hA, hB, hC⟩
  exact not_both_nonresidue_of_barring_character hrel hs ht hC ⟨hA, hB⟩

 









theorem not_both_primitiveRoot_five_ten
    (hp2 : p ≠ 2) (hp5 : (5 : ZMod p) ≠ 0)
    (hmod : p % 8 = 3 ∨ p % 8 = 5)
    (h5 : IsPrimitiveRoot (((5 : ℤ) : ZMod p)) (p - 1))
    (h10 : IsPrimitiveRoot (((10 : ℤ) : ZMod p)) (p - 1)) :
    False := by
  have hd : legendreSym p 2 = -1 := by
    rw [legendreSym.at_two hp2, ZMod.χ₈_nat_mod_eight]
    rcases hmod with h | h <;> rw [h] <;> decide
  refine not_both_primitiveRoot_of_barring_character hp2
    (d := 2) (u := 5) (v := 1) (by ring) ?_ ?_ hd h5 h10
  · push_cast
    exact hp5
  · simp

 





theorem not_both_primitiveRoot_two_six
    (hp2 : p ≠ 2)
    (hd : legendreSym p 3 = -1)
    (h2 : IsPrimitiveRoot (((2 : ℤ) : ZMod p)) (p - 1))
    (h6 : IsPrimitiveRoot (((6 : ℤ) : ZMod p)) (p - 1)) :
    False := by
  refine not_both_primitiveRoot_of_barring_character hp2
    (d := 3) (u := 2) (v := 1) (by ring) ?_ ?_ hd h2 h6
  · 
    have hp : (p : ℕ).Prime := Fact.out
    have hne : ((2 : ℕ) : ZMod p) ≠ 0 := by
      rw [Ne, ZMod.natCast_eq_zero_iff]
      intro hdvd
      exact hp2 (((Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp hdvd))
    simpa using hne
  · simp

end ArtinExclusion
