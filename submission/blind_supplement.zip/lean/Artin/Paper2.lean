 




import Mathlib.NumberTheory.LegendreSymbol.Basic
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Tactic

set_option linter.style.header false

 

















































namespace Paper2

 

 


theorem three_primitiveRoot_five :
    (3 : ZMod 5) ^ 4 = 1 ∧ (3 : ZMod 5) ^ 1 ≠ 1 ∧ (3 : ZMod 5) ^ 2 ≠ 1 := by
  refine ⟨by decide, by decide, by decide⟩

 

theorem three_primitiveRoot_seven :
    (3 : ZMod 7) ^ 6 = 1 ∧ (3 : ZMod 7) ^ 1 ≠ 1 ∧ (3 : ZMod 7) ^ 2 ≠ 1 ∧
      (3 : ZMod 7) ^ 3 ≠ 1 := by
  refine ⟨by decide, by decide, by decide, by decide⟩

 
theorem group_orders : Fintype.card (ZMod 5)ˣ = 4 ∧ Fintype.card (ZMod 7)ˣ = 6 := by
  refine ⟨by decide, by decide⟩

 



theorem refutation_gap_two_base_three :
    Nat.Prime 5 ∧ Nat.Prime 7 ∧ 7 - 5 = 2 ∧
      ((3 : ZMod 5) ^ 4 = 1 ∧ (3 : ZMod 5) ^ 2 ≠ 1) ∧
      ((3 : ZMod 7) ^ 6 = 1 ∧ (3 : ZMod 7) ^ 3 ≠ 1 ∧ (3 : ZMod 7) ^ 2 ≠ 1) := by
  refine ⟨by norm_num, by norm_num, by norm_num, ⟨by decide, by decide⟩,
    ⟨by decide, by decide, by decide⟩⟩

 




 

def chi (d : ℕ) [NeZero d] (r : ZMod d) : ℤ :=
  if r = 0 then 0 else if r ^ ((d - 1) / 2) = 1 then 1 else -1

 

def nmm (d : ℕ) [NeZero d] (g : ZMod d) : ℕ :=
  (Finset.univ.filter fun r : ZMod d => chi d r = -1 ∧ chi d (r + g) = -1).card

 

theorem nmm_five (g : ZMod 5) :
    (g = 0 → nmm 5 g = 2) ∧ (g ≠ 0 → 4 * (nmm 5 g : ℤ) = 5 - 3 + 2 * chi 5 g) := by
  revert g; decide

 

theorem nmm_thirteen (g : ZMod 13) :
    (g = 0 → nmm 13 g = 6) ∧
      (g ≠ 0 → 4 * (nmm 13 g : ℤ) = 13 - 3 + 2 * chi 13 g) := by
  revert g; decide

 

theorem paper_formula_fails_at_zero :
    4 * (nmm 13 0 : ℤ) ≠ 13 - 3 + 2 * chi 13 0 := by decide

 

theorem nmm_five_vanishes (g : ZMod 5) : nmm 5 g = 0 ↔ (g = 2 ∨ g = 3) := by
  revert g; decide

 

theorem nmm_thirteen_never_vanishes (g : ZMod 13) : nmm 13 g ≠ 0 := by
  revert g; decide

end Paper2
