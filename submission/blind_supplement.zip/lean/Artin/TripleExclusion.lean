 




import Mathlib.NumberTheory.LegendreSymbol.Basic
import Mathlib.Tactic
import Artin.PrimitiveRootBridge

set_option linter.style.header false

 




































namespace ArtinExclusion

open ZMod

variable {p : ℕ} [Fact p.Prime]

 
private theorem legendreSym_sq {s : ℤ} (hs : ((s : ZMod p)) ≠ 0) :
    legendreSym p (s ^ 2) = 1 := by
  have : legendreSym p (s ^ 2) = (legendreSym p s) ^ 2 := by
    rw [sq, sq, legendreSym.mul]
  rw [this]
  rcases legendreSym.eq_one_or_neg_one p hs with h | h <;> rw [h] <;> norm_num

 













theorem not_all_three_nonresidue
    {a b c s t : ℤ}
    (hrel : c * s ^ 2 = a * b * t ^ 2)
    (hs : ((s : ZMod p)) ≠ 0) (ht : ((t : ZMod p)) ≠ 0) :
    ¬ (legendreSym p a = -1 ∧ legendreSym p b = -1 ∧ legendreSym p c = -1) := by
  rintro ⟨hA, hB, hC⟩
  
  have h := congrArg (fun z : ℤ => legendreSym p z) hrel
  simp only [legendreSym.mul, legendreSym_sq hs, legendreSym_sq ht, mul_one] at h
  
  rw [hA, hB, hC] at h
  norm_num at h

 



theorem legendreSym_third_eq_one
    {a b c s t : ℤ}
    (hrel : c * s ^ 2 = a * b * t ^ 2)
    (hs : ((s : ZMod p)) ≠ 0) (ht : ((t : ZMod p)) ≠ 0)
    (hA : legendreSym p a = -1) (hB : legendreSym p b = -1) :
    legendreSym p c = 1 := by
  have h := congrArg (fun z : ℤ => legendreSym p z) hrel
  simp only [legendreSym.mul, legendreSym_sq hs, legendreSym_sq ht, mul_one] at h
  rw [hA, hB] at h
  simp only [neg_mul, neg_neg, one_mul] at h
  exact h

 


theorem not_all_three_nonresidue_two_five_ten :
    ¬ (legendreSym p 2 = -1 ∧ legendreSym p 5 = -1 ∧ legendreSym p 10 = -1) := by
  refine not_all_three_nonresidue (s := 1) (t := 1) (by ring) ?_ ?_
  · simp
  · simp

 






theorem not_all_three_nonresidue_of_primitiveRoot
    (hp2 : p ≠ 2)
    {a b c s t : ℤ}
    (hrel : c * s ^ 2 = a * b * t ^ 2)
    (hs : ((s : ZMod p)) ≠ 0) (ht : ((t : ZMod p)) ≠ 0)
    (ha : IsPrimitiveRoot ((a : ZMod p)) (p - 1))
    (hb : IsPrimitiveRoot ((b : ZMod p)) (p - 1))
    (hC : legendreSym p c = -1) :
    False :=
  not_all_three_nonresidue hrel hs ht
    ⟨legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 ha,
     legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 hb, hC⟩

 




theorem legendreSym_third_eq_one_of_primitiveRoot
    (hp2 : p ≠ 2)
    {a b c s t : ℤ}
    (hrel : c * s ^ 2 = a * b * t ^ 2)
    (hs : ((s : ZMod p)) ≠ 0) (ht : ((t : ZMod p)) ≠ 0)
    (ha : IsPrimitiveRoot ((a : ZMod p)) (p - 1))
    (hb : IsPrimitiveRoot ((b : ZMod p)) (p - 1)) :
    legendreSym p c = 1 :=
  legendreSym_third_eq_one hrel hs ht
    (legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 ha)
    (legendreSym_eq_neg_one_of_isPrimitiveRoot hp2 hb)

end ArtinExclusion
