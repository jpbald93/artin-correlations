 




import Mathlib.NumberTheory.LegendreSymbol.QuadraticReciprocity
import Mathlib.NumberTheory.LegendreSymbol.QuadraticChar.Basic
import Mathlib.Tactic

set_option linter.style.header false

 





















namespace ArtinExclusion

 

def chi2 (r : ZMod 40) : ℤ :=
  if r.val % 8 = 1 ∨ r.val % 8 = 7 then 1 else -1

 

def chi5 (r : ZMod 40) : ℤ :=
  if r.val % 5 = 1 ∨ r.val % 5 = 4 then 1 else -1

 
def chi10 (r : ZMod 40) : ℤ := chi2 r * chi5 r

 
theorem chi10_ne_zero : ∀ r : ZMod 40, chi10 r = 1 ∨ chi10 r = -1 := by decide

 


theorem chi10_shift_twenty : ∀ r : ZMod 40, IsUnit r → chi10 (r + 20) = - chi10 r := by
  decide

 


theorem chi10_shift_zero : ∀ r : ZMod 40, chi10 (r + 40) = chi10 r := by decide

 


theorem not_both_nonresidue :
    ∀ r : ZMod 40, IsUnit r → ¬ (chi10 r = -1 ∧ chi10 (r + 20) = -1) := by
  decide

 

theorem chi10_shift_of_gap (r g : ZMod 40) (hr : IsUnit r) (hg : g = 20) :
    chi10 (r + g) = - chi10 r := by
  subst hg
  exact chi10_shift_twenty r hr

end ArtinExclusion
