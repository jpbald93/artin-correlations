 





import Mathlib.NumberTheory.LegendreSymbol.Basic
import Mathlib.RingTheory.RootsOfUnity.PrimitiveRoots

set_option linter.style.header false

 








































 

theorem isPrimitiveRoot_imp_legendreSym_eq_neg_one
    {p : ℕ} [hp_fact : Fact p.Prime] (hp2 : p ≠ 2) (a : ZMod p)
    (ha : IsPrimitiveRoot a (p - 1)) :
    legendreSym p (ZMod.val a) = -1 := by
  have hp : p.Prime := hp_fact.out
  have hp1 : p ≠ 1 := hp.ne_one
  have ha_order_eq : orderOf a = p - 1 := IsPrimitiveRoot.iff_orderOf.mp ha
  have h_leg_eq : (legendreSym p (ZMod.val a) : ZMod p) = a ^ (p / 2) := by
    have := legendreSym.eq_pow p (ZMod.val a)
    simpa using this
  have hgt2 : p ≥ 3 := by
    have := hp.two_le
    omega
  have hlt : p / 2 < p - 1 := by omega
  have ha_ne_zero : (a : ZMod p) ≠ 0 := by
    intro h0
    apply ha.ne_zero (Nat.sub_ne_zero_of_lt hp.one_lt)
    simpa using h0
  have ha_ne_zero' : ((ZMod.val a : ℕ) : ZMod p) ≠ 0 := by simpa using ha_ne_zero
  by_contra h_ne
  have hcases := legendreSym.eq_one_or_neg_one
    (p := p) (a := (ZMod.val a : ℤ)) (by simpa using ha_ne_zero')
  have hone : legendreSym p (ZMod.val a) = 1 := hcases.resolve_right h_ne
  rw [hone] at h_leg_eq
  have h_eq_one' : a ^ (p / 2) = 1 := by simpa using h_leg_eq.symm
  have h_order_dvd : orderOf a ∣ p / 2 := orderOf_dvd_of_pow_eq_one h_eq_one'
  rw [ha_order_eq] at h_order_dvd
  have hpos : 0 < p / 2 := by omega
  have := Nat.le_of_dvd hpos h_order_dvd
  omega

 





theorem legendreSym_eq_neg_one_of_isPrimitiveRoot
    {p : ℕ} [Fact p.Prime] (hp2 : p ≠ 2) {a : ℤ}
    (ha : IsPrimitiveRoot ((a : ZMod p)) (p - 1)) :
    legendreSym p a = -1 := by
  have h := isPrimitiveRoot_imp_legendreSym_eq_neg_one hp2 (a : ZMod p) ha
  have hcast : ((ZMod.val ((a : ZMod p)) : ℤ) : ZMod p) = (a : ZMod p) := by
    push_cast
    exact ZMod.natCast_zmod_val _
  have heq : legendreSym p ((ZMod.val ((a : ZMod p)) : ℤ)) = legendreSym p a := by
    unfold legendreSym
    rw [hcast]
  rwa [heq] at h
