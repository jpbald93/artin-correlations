 




import Artin.Exclusion

set_option linter.style.header false

 














namespace ArtinExclusion

open ZMod

variable {p : ℕ} [Fact p.Prime]

 
private theorem cast_prime_ne_zero {q : ℕ} (hq : q.Prime) (hne : p ≠ q) :
    ((q : ℕ) : ZMod p) ≠ 0 := by
  intro h
  exact hne ((Nat.prime_dvd_prime_iff_eq Fact.out hq).mp
    ((ZMod.natCast_eq_zero_iff q p).mp h))

 
theorem legendreSym_two_eq (hp2 : p ≠ 2) :
    legendreSym p 2 = if p % 8 = 1 ∨ p % 8 = 7 then 1 else -1 := by
  have hne : ((2 : ℕ) : ZMod p) ≠ 0 := cast_prime_ne_zero Nat.prime_two hp2
  by_cases h : p % 8 = 1 ∨ p % 8 = 7
  · simp only [h, if_true]
    have : legendreSym p (2 : ℕ) = 1 :=
      (legendreSym.eq_one_iff' p hne).mpr ((ZMod.exists_sq_eq_two_iff hp2).mpr h)
    simpa using this
  · simp only [h, if_false]
    have : legendreSym p (2 : ℕ) = -1 :=
      (legendreSym.eq_neg_one_iff' p).mpr
        (fun hsq => h ((ZMod.exists_sq_eq_two_iff hp2).mp hsq))
    simpa using this

 





private theorem isSquare_cast_five (n : ℕ) (hn : n % 5 ≠ 0) :
    IsSquare ((n : ℕ) : ZMod 5) ↔ (n % 5 = 1 ∨ n % 5 = 4) := by
  have hcast : ((n : ℕ) : ZMod 5) = ((n % 5 : ℕ) : ZMod 5) := by
    have := ZMod.natCast_mod n 5
    exact this.symm
  have hlt : n % 5 < 5 := Nat.mod_lt _ (by norm_num)
  rw [hcast]
  
  have h5 : n % 5 = 0 ∨ n % 5 = 1 ∨ n % 5 = 2 ∨ n % 5 = 3 ∨ n % 5 = 4 := by omega
  rcases h5 with h | h | h | h | h
  · exact absurd h hn
  · simp only [h]
    exact ⟨fun _ => Or.inl trivial, fun _ => ⟨1, by decide⟩⟩
  · simp only [h]
    exact ⟨by decide, by omega⟩
  · simp only [h]
    exact ⟨by decide, by omega⟩
  · simp only [h]
    exact ⟨fun _ => Or.inr trivial, fun _ => ⟨2, by decide⟩⟩

 
theorem legendreSym_five_eq (hp5 : p ≠ 5) (hp2 : p ≠ 2) :
    legendreSym p 5 = if p % 5 = 1 ∨ p % 5 = 4 then 1 else -1 := by
  have h5fact : Fact (Nat.Prime 5) := ⟨by norm_num⟩
  have hne5 : ((5 : ℕ) : ZMod p) ≠ 0 := cast_prime_ne_zero (by norm_num) hp5
  
  have hpprime : Nat.Prime p := Fact.out
  have hpmod : p % 5 ≠ 0 := by
    intro h
    have h5dvd : (5 : ℕ) ∣ p := Nat.dvd_of_mod_eq_zero h
    exact hp5 ((Nat.prime_dvd_prime_iff_eq (by norm_num) hpprime).mp h5dvd).symm
  
  have key : IsSquare ((5 : ℕ) : ZMod p) ↔ IsSquare ((p : ℕ) : ZMod 5) :=
    (ZMod.exists_sq_eq_prime_iff_of_mod_four_eq_one (p := 5) (q := p)
      (by norm_num) hp2).symm
  by_cases h : p % 5 = 1 ∨ p % 5 = 4
  · simp only [h, if_true]
    have : legendreSym p (5 : ℕ) = 1 :=
      (legendreSym.eq_one_iff' p hne5).mpr (key.mpr ((isSquare_cast_five p hpmod).mpr h))
    simpa using this
  · simp only [h, if_false]
    have : legendreSym p (5 : ℕ) = -1 :=
      (legendreSym.eq_neg_one_iff' p).mpr
        (fun hsq => h ((isSquare_cast_five p hpmod).mp (key.mp hsq)))
    simpa using this

 


theorem chi10_eq_legendreSym (hp2 : p ≠ 2) (hp5 : p ≠ 5) :
    chi10 (p : ZMod 40) = legendreSym p 10 := by
  have h10 : legendreSym p 10 = legendreSym p 2 * legendreSym p 5 := by
    have : (10 : ℤ) = 2 * 5 := by norm_num
    rw [this, legendreSym.mul]
  rw [h10, legendreSym_two_eq hp2, legendreSym_five_eq hp5 hp2]
  have hv : ((p : ZMod 40)).val = p % 40 := ZMod.val_natCast 40 p
  have h8 : p % 40 % 8 = p % 8 := Nat.mod_mod_of_dvd p (by norm_num)
  have h5 : p % 40 % 5 = p % 5 := Nat.mod_mod_of_dvd p (by norm_num)
  simp only [chi10, chi2, chi5, hv, h8, h5]

end ArtinExclusion
