 




import Mathlib.Tactic

set_option linter.style.header false
set_option linter.unusedDecidableInType false

 

































namespace Paper2Rebuild

open Finset

 

 

theorem four_mul_indicator {x y : ℤ} (hx : x = -1 ∨ x = 1) (hy : y = -1 ∨ y = 1) :
    4 * (if x = -1 ∧ y = -1 then (1 : ℤ) else 0) = (1 - x) * (1 - y) := by
  rcases hx with hx | hx <;> rcases hy with hy | hy <;> subst hx <;> subst hy <;> norm_num

 






theorem main_identity {α : Type*} [DecidableEq α] (U : Finset α) (f h : α → ℤ)
    (hf : ∀ r ∈ U, f r = -1 ∨ f r = 1) (hh : ∀ r ∈ U, h r = -1 ∨ h r = 1) :
    4 * ((U.filter fun r => f r = -1 ∧ h r = -1).card : ℤ)
      = (U.card : ℤ) - (∑ r ∈ U, f r) - (∑ r ∈ U, h r) + (∑ r ∈ U, f r * h r) := by
  have key : 4 * ((U.filter fun r => f r = -1 ∧ h r = -1).card : ℤ)
      = ∑ r ∈ U, (1 - f r) * (1 - h r) := by
    rw [Finset.card_filter]
    push_cast
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun r hr => ?_
    exact four_mul_indicator (hf r hr) (hh r hr)
  rw [key]
  have expand : ∀ r ∈ U, (1 - f r) * (1 - h r)
      = 1 - f r - h r + f r * h r := fun r _ => by ring
  rw [Finset.sum_congr rfl expand]
  simp [Finset.sum_add_distrib, Finset.sum_sub_distrib]

 

theorem counting_identity {α : Type*} [DecidableEq α] (U : Finset α) (f h : α → ℤ)
    (hf : ∀ r ∈ U, f r = -1 ∨ f r = 1) (hh : ∀ r ∈ U, h r = -1 ∨ h r = 1)
    (N T A B S : ℤ)
    (hN : N = ((U.filter fun r => f r = -1 ∧ h r = -1).card : ℤ))
    (hT : T = (U.card : ℤ)) (hA : A = ∑ r ∈ U, f r) (hB : B = ∑ r ∈ U, h r)
    (hS : S = ∑ r ∈ U, f r * h r) :
    4 * N = T - A - B + S := by
  subst hN hT hA hB hS
  exact main_identity U f h hf hh

end Paper2Rebuild
